use Database2
--Q1
select * from [dbo].[Sales_Data$];
exec sp_rename '[dbo].[Sales_Data$].State','Statee','COLUMN';

select Statee,count(distinct OrderID) AS TotalOrders,
sum(Quantity) as TotalQuantity,
sum(NetSales) as TotalNetSales,
sum(Profit) as TotalProfit,
sum(NetSales)/ count(OrderID) as AverageOrderValue
from [dbo].[Sales_Data$] where OrderStatus='Completed'
group by Statee having sum(NetSales)>1000000 order by sum(NetSales) desc

--Q2
with CustomerSales as (
select CustomerID,CustomerName,sum(NetSales) as TotalNetSales
from [dbo].[Sales_Data$] where OrderStatus='Completed'
group  by CustomerID,CustomerName)
select top 5 CustomerID,CustomerName, TotalNetSales from CustomerSales order by TotalNetSales desc

--Q3
with StateSales as(
select Statee,sum(NetSales) as TotalNetSales from [dbo].[Sales_Data$] where OrderStatus='Completed'
group by Statee)
select Statee,TotalNetSales,
dense_rank() over(order by TotalNetSales desc) as SalesRank from StateSales order by SalesRank




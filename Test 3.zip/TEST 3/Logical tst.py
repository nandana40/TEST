# 1.
li=[12,7,12,5,7,9,5,12,9,7,15]
duplicates=[]
for i in li:
    if li.count(i)>1 and i not in duplicates:
        duplicates.append(i)
for i in duplicates:
    print(i,"->",li.count(i),"times")
    
# 2.
ids=[1,2,3,4,5,7,8,9,10]
for i in range(1,11):
    if i not in ids:
        print(i,"MISSING ID")